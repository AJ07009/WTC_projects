# -------------------------------------------------------------------------------------------------
#
# TODO: Please replace this placeholder code with your solution for Toy Robot 4, and work from there.
#
# -------------------------------------------------------------------------------------------------

def robot_start():
    """
    Replace me!
    """
    pass


if __name__ == "__main__":
    robot_start()
