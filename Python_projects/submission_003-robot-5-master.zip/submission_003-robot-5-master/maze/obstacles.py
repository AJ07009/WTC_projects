# -------------------------------------------------------------------------------------------------
#
# TODO: Please replace this placeholder code with your solution for Toy Robot 4, and work from there.
#
# -------------------------------------------------------------------------------------------------

def create_random_obstacles():
    pass


def is_position_blocked(x, y):
    pass


def is_path_blocked(x1, y1, x2, y2):
    pass

def get_obstacles():
    pass